enum ColType
{
	
	Enemy			= 1,
	Filth			= 2,
	Particle		= 3,
	Prop			= 4,
	Player			= 5,
	Spring			= 6,
	Hittable		= 7,
	Hitbox			= 8,
	Poi				= 9,
	PoiArea			= 10,
	Projectile		= 11,
	Camera_node		= 12,
	Emitter			= 13,
	Cleansed		= 14,
	Ai_controller	= 15,
	Trigger			= 16,
	CheckPoint		= 17,
	LevelBoundary	= 18,
	LevelStart		= 19,
	TriggerArea		= 20,
	KillZone		= 21,
	Null			= 22,
	
}

enum EmitterId
{
	
	DropletLong = 131,
	Droplet = 113,
	DustGround = 1,
	Fireflies = 58,
	FireflyDense = 66,
	KingZone = 122,
	KingZoneBlue = 125,
	KingZoneRed = 126,
	LeafGround = 4,
	PolygonsGround = 70,
	Rain = 114,
	SlimeGround = 10,
	Sparks = 107,
	TrashGround = 7,
	Waterfall = 42,
	WaterfallBack = 49,
	WaterfallTop = 41,
	
	
	Cleansed1 = 39,
	Cleansed2 = 46,
	Cleansed3 = 46,
	Cleansed4 = 90,
	Cleansed5 = 81,
	
	Cleansed3b = 99,
	
	CleansedFb1 = 68,
	CleansedFb2 = 67,
	CleansedFb3 = 115,
	CleansedFb4 = 104,
	CleansedFb5 = 79,
	
	// Aliases for area tile emitters
	
	TileCleansedMansion	= CleansedFb1,
	TileCleansedForest	= CleansedFb2,
	TileCleansedCity	= CleansedFb3,
	TileCleansedLab		= CleansedFb4,
	TileCleansedVirtual	= CleansedFb5,
	
}

float frand()
{
	return float(rand()) / float(0x3fffffff);
}
int rand_range(int min, int max)
{
	return min + (rand() % (max - min + 1));
}
float rand_range(float min, float max)
{
	return min + (max - min) * frand();
}

void outline_rect(scene@ g, float x1, float y1, float x2, float y2, uint layer, uint sub_layer, float thickness=2, uint colour=0xFFFFFFFF)
{
	// Top
	g.draw_rectangle_world(layer, sub_layer,
		x1 - thickness, y1 - thickness,
		x2 + thickness, y1 + thickness,
		0, colour);
	// Bottom
	g.draw_rectangle_world(layer, sub_layer,
		x1 - thickness, y2 - thickness,
		x2 + thickness, y2 + thickness,
		0, colour);
	// Left
	g.draw_rectangle_world(layer, sub_layer,
		x1 - thickness, y1 - thickness,
		x1 + thickness, y2 + thickness,
		0, colour);
	// Right
	g.draw_rectangle_world(layer, sub_layer,
		x2 - thickness, y1 - thickness,
		x2 + thickness, y2 + thickness,
		0, colour);
}

entity@ create_emitter(int id, float x, float y, int width, int height, int layer, int sub_layer)
{
	entity@ emitter = create_entity("entity_emitter");
	varstruct@ vars = emitter.vars();
	emitter.layer(layer);
	vars.get_var("emitter_id").set_int32(id);
	vars.get_var("width").set_int32(width);
	vars.get_var("height").set_int32(height);
	vars.get_var("draw_depth_sub").set_int32(sub_layer);
	vars.get_var("r_area").set_bool(true);
	emitter.set_xy(x, y);
	
	return emitter;
}

EmitterId get_emitter_if_for_area(int area)
{
	switch(area)
	{
		case 1: return EmitterId::TileCleansedMansion;
		case 2: return EmitterId::TileCleansedForest;
		case 3: return EmitterId::TileCleansedCity;
		case 4: return EmitterId::TileCleansedLab;
		case 5: return EmitterId::TileCleansedVirtual;
	}
	
	return EmitterId::TileCleansedMansion;
}

class RemoveTimer : trigger_base
{
	
	scripttrigger@ self;
	
	int timer = 0;
	int duration = 0;
	entity@ e;
	
	RemoveTimer()
	{
	}
	
	RemoveTimer(entity@ e, int duration)
	{
		@this.e = e;
		this.duration = duration;
	}
	
	void init(script@ s, scripttrigger@ self)
	{
		@this.self = self;
	}
	
	void step()
	{
		if(++timer >= duration)
		{
			if(@e != null)
				get_scene().remove_entity(e);
			get_scene().remove_entity(self.as_entity());
		}
	}
	
}

RemoveTimer@ remove_timer(entity@ e, int duration)
{
	RemoveTimer@ timer = RemoveTimer(e, duration);
	scripttrigger@ st = create_scripttrigger(timer);
	st.set_xy(e.x(), e.y());
	get_scene().add_entity(@st.as_entity(), false);
	
	return timer;
}

class Fx : trigger_base
{
	scene@ g;
	script@ script;
	scripttrigger@ self;
	
	sprites@ sprite;
	[text] string sprite_set;
	[text] string sprite_name;
	[text] uint palette;
	
	float rotation;
	float scale_x = 1;
	float scale_y = 1;
	uint colour;
	
	int layer = 18;
	int sublayer = 14;
	
	float start_frame = 0;
	float end_frame = -1;
	float frame = 0;
	float frame_rate;
	int frame_count;
	int loop = -1;
	
	Fx()
	{
	}
	
	Fx(string sprite_set, string sprite_name, uint palette=0, float fps=15, float rotation=0, float scale_x=1, float scale_y=1, uint colour=0xFFFFFFFF)
	{
		this.sprite_set = sprite_set;
		this.sprite_name = sprite_name;
		this.palette = palette;
		this.rotation = rotation;
		this.scale_x = scale_x;
		this.scale_y = scale_y;
		this.colour = colour;
		
		frame_rate = fps / 60.0;
	}
	
	void init(script@ script, scripttrigger@ self)
	{
		@this.script = @script;
		@this.self = @self;
		
		@sprite = create_sprites();
		sprite.add_sprite_set(sprite_set);
		frame_count = sprite.get_animation_length(sprite_name);
		
		if(frame_rate < 0) frame = end_frame;
		
		if(end_frame == -1)
		{
			end_frame = frame_count;
		}
	}
	
	Fx@ set_layer(int layer, int sub_layer)
	{
		this.layer = layer;
		this.sublayer = sub_layer;
		return this;
	}
	
	void step()
	{
		frame += frame_rate;
		
		if(frame_rate > 0)
		{
			if(frame > end_frame)
			{
				if(loop > 0)
				{
					frame -= end_frame - start_frame;
					loop--;
				}
				else
				{
					get_scene().remove_entity(self.as_entity());
				}
			}
		}
		else
		{
			if(frame < start_frame)
			{
				if(loop > 0)
				{
					frame = end_frame + frame;
					loop--;
				}
				else
				{
					get_scene().remove_entity(self.as_entity());
				}
			}
		}
	}
	
	void draw(float sub_frame)
	{
		sprite.draw_world(layer, sublayer, sprite_name,
				uint(frame), palette, self.x(), self.y(), rotation,
				scale_x, scale_y, colour);
	}
	
}

Fx@ spawn_fx(float x, float y, string sprite_set, string sprite_name, uint palette=0, float fps=15, float rotation=0, float scale_x=1, float scale_y=1, uint colour=0xFFFFFFFF)
{
	Fx@ fx = Fx(sprite_set, sprite_name, palette, fps, rotation, scale_x, scale_y, colour);
	scripttrigger@ st = create_scripttrigger(fx);
	st.x(x);
	st.y(y);
	get_scene().add_entity(@st.as_entity(), false);
	
	return fx;
}