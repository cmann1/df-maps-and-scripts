// #include 'lib/std.cpp'
#include 'shared/BreakableWall.cpp'

class script
{
	
	
}