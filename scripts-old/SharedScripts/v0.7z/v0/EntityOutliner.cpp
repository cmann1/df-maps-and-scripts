const int ATTACK_TYPE_IDLE = 0;

float lerp(float a, float b, float x)
{
	return a * (1.0 - x) + b * x;
}

class script
{
	
	[text] EntityOutliner entity_outliner;
	
	script()
	{
	}
	
	void step(int entities)
	{
		entity_outliner.step(entities);
	}
	
	void draw(float sub_frame)
	{
		entity_outliner.draw(sub_frame);
	}
	
}

class EntityOutliner
{
	
	[colour,alpha] uint colour = 0xFFFFFFFF;
	[text] bool draw_double = false;
	
	[text] int apple_layer = 18;
	[text] int apple_sublayer = 6;
	
	[text] int enemy_layer = 18;
	[text] int enemy_sublayer = 7;
	
	[text] int player_layer = 18;
	[text] int player_sublayer = 9;
	
	[text] float offset_x = 2;
	[text] float offset_y = -2;
	
	array<controllable@> entity_list;
	
	void step(int entities)
	{
		entity_list.resize(0);
		
		for(int i = 0; i < entities; i++)
		{
			controllable@ c = entity_by_index(i).as_controllable();
			if(@c != null and c.life() > 0)
			{
				entity_list.insertLast(c);
			}
		}
	}
	
	void draw(float sub_frame)
	{
		for(uint count = entity_list.length(), i = 0; i < count; i++)
		{
			controllable@ c = entity_list[i];
			if(c.life() <= 0) continue;
			sprites@ spr = c.get_sprites();
			
			string sprite_name;
			uint frame;
			float face;
			if(c.attack_state() == ATTACK_TYPE_IDLE)
			{
				sprite_name = c.sprite_index();
				frame = uint(c.state_timer());
				face = c.face();
			}
			else
			{
				sprite_name = c.attack_sprite_index();
				frame = uint(c.attack_timer());
				face = c.attack_face();
			}
			frame = frame % spr.get_animation_length(sprite_name);
			
			const float x = lerp(c.prev_x(), c.x(), sub_frame) + c.draw_offset_x();
			const float y = lerp(c.prev_y(), c.y(), sub_frame) + c.draw_offset_y();
			
			const string type_name = c.type_name();
			int layer, sublayer;
			
			if(type_name == "hittable_apple")
			{
				layer = apple_layer;
				sublayer = apple_sublayer;
			}
			else if(type_name.substr(0, 5) == "dust_")
			{
				layer = player_layer;
				sublayer = player_sublayer;
			}
			else
			{
				layer = enemy_layer;
				sublayer = enemy_sublayer;
			}
			
			spr.draw_world(
				layer, sublayer,
				sprite_name, frame, 0,
				x + offset_x, y + offset_y,
				c.rotation(), c.scale() * face, c.scale(), colour);
			
			if(draw_double)
			{
				spr.draw_world(
					layer, sublayer,
					sprite_name, frame, 0,
					x - offset_x, y - offset_y,
					c.rotation(), c.scale() * face, c.scale(), colour);
			}
		}
	}
	
}