/*
 * Script configuration START >>>>>>>>>>>>>>>>>>>>>>>>>>>>
 */

// Layers that are used as portals
const array<int> PORTAL_LAYERS = {14, 15};
// Corresponds to the PORTAL_LAYERS array above. Determines which portals the player is allowed to enter
const array<bool> IN_PORTAL_LAYERS = {true, false};
// Which layer is used to link portals
const int PORTAL_LINK_LAYER = 12;

// Just on case, should prevent infinite loops if the linking tiles aren't properly structured
const uint MAX_LINK_LENGTH = 1000;

/*
 * <<<<<<<<<<<<<<<<<<<<<<<<<<<< Script configuration END
 */

const int MAX_PLAYERS = 4;

const int PORTAL_LAYER_COUNT = PORTAL_LAYERS.length();

const float PI = 3.1415926535897932384626433832795;

float dot(float x1, float y1, float x2, float y2)
{
	return x1 * x2 + y1 * y2;
}

void rotate(float point_x, float point_y, float angle, float &out out_x, float &out out_y)
{
	float cos_angle = cos(angle);
	float sin_angle = sin(angle);
	
	out_x = cos_angle * point_x - sin_angle * point_y;
	out_y = sin_angle * point_x + cos_angle * point_y;
}

// Used when tracing portal tiles
class TileQueue
{
	dictionary checked = {};
	array<int> queued(10);
	uint queued_count;

	void init(int start_x, int start_y)
	{
		queued.resize(20);
		queued[0] = start_x;
		queued[1] = start_y;
		queued_count = 2;
	}

	void reset()
	{
		checked.deleteAll();
		queued.resize(0);
	}

	void add_tile(int tile_x, int tile_y)
	{
		if (!checked.exists(tile_x + "/" + tile_y))
		{
			if (queued.length() == queued_count) queued.resize(queued_count + 10);
			queued[queued_count++] = tile_x;
			queued[queued_count++] = tile_y;
		}
	}
};

class Portal
{
	float mid_x;
	float mid_y;
	float normal_x;
	float normal_y;
	float angle; // Radians
	float length; // Radians

	Portal@ linked_portal = null;
	bool allow_in = true;

	Portal() { }

	void init_angle(int angle_deg)
	{
		angle = float(angle_deg) / 180.0 * PI;
		normal_x = sin(angle);
		normal_y = -cos(angle);
	}
};

class Player
{
	dustman@ player = null;
	
	// Track which portal the player is coming out of to prevent instantly teleporting back through it
	Portal@ out_portal = null;
}

class script{
	scene@ g;
	controllable@ player;
	dustman@ dm;
	
	array<Player> players(MAX_PLAYERS);
	
	// Maps tiles (x/y) to portals
	dictionary portals = {};
	
	Portal@ out_portal = null;

	TileQueue@ primary_queue = TileQueue();
	TileQueue@ secondary_queue = TileQueue();

	// Game callbacks

	script(){
		@g = get_scene();
	}
	
	void checkpoint_save() {
	}

	void checkpoint_load() {
		@player = null;
		for(int i = 0; i < MAX_PLAYERS; i++)
		{
			Player@ p = @players[i];
			@p.player = null;
			@p.out_portal = null;
		}
	}
	
	// Returns the portal at the given location, or null.
	Portal@ get_portal(int tile_x, int tile_y)
	{
		string portal_key = tile_x + "/" + tile_y;
		if (portals.exists(portal_key))
		{
			return cast<Portal>(portals[portal_key]);
		}
		else
		{
			// puts("Found new portal [" + tile_x + ", " + tile_y + "]");
			return trace_portal(primary_queue, tile_x, tile_y);
		}
	}
	
	bool has_portal(int tile_x, int tile_y)
	{
		return portals.exists(tile_x + "/" + tile_y);
	}

	void step(int entityCount){
		for(int player_index = 0; player_index < MAX_PLAYERS; player_index++)
		{
			Player@ p = @players[player_index];
			dustman@ player = p.player;
			
			if(@player == null){
				entity@e = controller_entity(player_index);
				if(@e != null){
					@p.player = @e.as_dustman();
				}
			}
			else{
				// Check the blocks around the player for portal tiles
				float player_x = player.x();
				float player_y = player.y();

				float padding_x = 7; // Shrink the player "hitbox" a little
				float padding_y = 10;
				
				int start_x = int(floor((player_x - 24 + padding_x) / 48));
				int start_y = int(floor((player_y - 96 + padding_y) / 48));
				int end_x = int(floor((player_x + 24 - padding_x) / 48));
				int end_y = int(floor((player_y - padding_y) / 48));
				int tile_x;
				int tile_y;

				tileinfo@ tile = null;
				int portal_layer;
				int other_portal_layer;
				bool found_portal_tile = false;

				for (int x = start_x; x <= end_x; x++)
				{
					for (int y = start_y; y <= end_y; y++)
					{
						for(int i = 0; i < PORTAL_LAYER_COUNT; i++){
							@tile = g.get_tile(x, y, PORTAL_LAYERS[i]);
							if(tile.solid()){
								tile_x = x;
								tile_y = y;
								found_portal_tile = true;
								break;
							}
						}
						
						if (found_portal_tile) break;
					}

					if (found_portal_tile) break;
				}

				///
				///

				if (found_portal_tile)
				{
					Portal@ portal = get_portal(tile_x, tile_y);
					
					if(p.out_portal is portal)
					{
						@portal = null;
					}
					else
					{
						@p.out_portal = null;
					}

					if (@portal != null and portal.allow_in and @portal.linked_portal != null)
					{
						Portal@ linked_portal = @portal.linked_portal;
						float x_speed = player.x_speed();
						float y_speed = player.y_speed();
						float speed = sqrt(x_speed * x_speed + y_speed * y_speed);

						float d = dot(x_speed, y_speed, portal.normal_x, portal.normal_y);
						float reflect_x = (x_speed - 2 * portal.normal_x * d);
						float reflect_y = (y_speed - 2 * portal.normal_y * d);
						
						// The portals are facing away from each other
						const float portal_facing = dot(portal.normal_x, portal.normal_y, linked_portal.normal_x, linked_portal.normal_y);
						if(portal_facing < 0)
						{
							reflect_x = -x_speed;
							reflect_y = -y_speed;
						}
						// Roughly in the same direction
						else
						{
							reflect_x = (x_speed - 2 * portal.normal_x * d);
							reflect_y = (y_speed - 2 * portal.normal_y * d);
						}
						
						// puts("TELEPORTING");
						float offset_angle = linked_portal.angle - portal.angle;
						float entity_angle = atan2(reflect_y, reflect_x) + offset_angle;
						x_speed = cos(entity_angle) * speed;
						y_speed = sin(entity_angle) * speed;
						
						// Project the players position onto the portal's surface
						float portal_dx = -portal.normal_y;
						float portal_dy = portal.normal_x;
						float player_dx = player_x - portal.mid_x;
						float player_dy = (player_y - 48) - portal.mid_y;
						float dp = dot(player_dx, player_dy, portal_dx, portal_dy);
						player_dx = -( dp / (portal_dx*portal_dx + portal_dy*portal_dy) ) * portal_dx;
						player_dy = -( dp / (portal_dx*portal_dx + portal_dy*portal_dy) ) * portal_dy;
						
						if(portal_facing > 0)
						{
							player_dx = -player_dx;
							player_dy = -player_dy;
						}
						
						// Scale the relative position so that if one portal is larger or smaller than the other the player
						// won't teleport outside of it
						if(portal.length != linked_portal.length)
						{
							player_dx = player_dx / portal.length * linked_portal.length;
							player_dy = player_dy / portal.length * linked_portal.length;
						}
						
						// Rotate the projected player's position to orient it to the other portal so that the player maintains it's relative position
						// when going through portals
						rotate(player_dx, player_dy, linked_portal.angle - portal.angle, portal_dx, portal_dy);
						// Also shift the player a little out of the portal to prevent clipping into walls behind the portal
						player.x(linked_portal.mid_x + portal_dx + (linked_portal.normal_x * 24));
						player.y(linked_portal.mid_y + 48 + portal_dy + (linked_portal.normal_y * 24));
						
						player.set_speed_xy(x_speed, y_speed);
						player.face(x_speed > 0 ? 1 : -1);
						
						// Force fall state if the player is dashing through the portal
						// st_dash = 9
						if(player.state() == 9)
						{
							if(abs(y_speed) > abs(x_speed))
								player.state(5); // st_fall
						}
						
						// reset_camera(0);
						
						@p.out_portal = @linked_portal;
					}
				}
				else
				{
					@p.out_portal = null;
				}
					
				
			}
		} // End for
	}

	Portal@ trace_portal(TileQueue@ tile_queue, int start_x, int start_y, bool find_link = true)
	{
		Portal@ portal = null;
		
		// Find the layer that this portal is on
		int portal_layer = -1;
		for(int i = 0; i < PORTAL_LAYER_COUNT; i++){
			tileinfo@ tile = g.get_tile(start_x, start_y, PORTAL_LAYERS[i]);
			if (tile.solid())
			{
				@portal = Portal();
				portal_layer = PORTAL_LAYERS[i];
				portal.allow_in = IN_PORTAL_LAYERS[i];
				break;
			}
		}
		
		if(portal_layer == -1)
		{
			return null;
		}
		
		tile_queue.init(start_x, start_y);
		
		int portal_angle = -1;
		float portal_x = 0;
		float portal_y = 0;
		int tile_count = 0;
		float portal_min_x = 9999999999.0;
		float portal_min_y = portal_min_x;
		float portal_max_x = -portal_min_x;
		float portal_max_y = -portal_min_x;

		// Perform a "flood fill" checking surrounding tiles for portal tiles
		while (tile_queue.queued_count > 0)
		{
			int tile_y = tile_queue.queued[--tile_queue.queued_count];
			int tile_x = tile_queue.queued[--tile_queue.queued_count];

			string tile_key = tile_x + "/" + tile_y;
			tile_queue.checked[tile_key] = true;

			// There's no tile here, so obviously it cannot be part of the portal
			tileinfo@ tile = g.get_tile(tile_x, tile_y, portal_layer);
			if (!tile.solid())
			{
				continue;
			}

			// Add the surrounding tiles to the queue, but only if they haven't been checked yet
			tile_queue.add_tile(tile_x - 1, tile_y);
			tile_queue.add_tile(tile_x + 1, tile_y);
			tile_queue.add_tile(tile_x, tile_y - 1);
			tile_queue.add_tile(tile_x, tile_y + 1);
			
			// Determine the exit angle of the portal
			// For angled tiles, if there's a tile covering it on layer 19, it means that this tile is facing into a wall and so it can be skipped
			if (portal_angle == -1)
			{
				tileinfo@ tile_collision = g.get_tile(tile_x, tile_y, 19);
				if (!tile_collision.solid())
				{
					int angle = tile.angle();
					if (angle == 1) angle = 0; // For some reason angle() returns 1 instead of 0 for full tiles

					// Angled/slanted tiles tiles take priority over full tiles
					// Why? - Because if a portal consists of both full and slanted tiles, the full tiles are only "filler" tiles
					// that are part of the portal's interior and therefore have no meaning when determining the angle of the portal.
					if (angle != 0)
					{
						portal_angle = angle;
					}
					else
					{
						// For vertical/horizontal portals all tiles are full tiles so we need to check surrounding tiles
						// to determine in which direction the portal is facing.
						if (is_tile_open(tile_x - 1, tile_y, portal_layer))
						{
							portal_angle = -90;
						}

						else if (is_tile_open(tile_x + 1, tile_y, portal_layer))
						{
							portal_angle = 90;
						}

						else if (is_tile_open(tile_x, tile_y - 1, portal_layer))
						{
							portal_angle = 0;
						}

						else if (is_tile_open(tile_x, tile_y + 1, portal_layer))
						{
							portal_angle = 180;
						}
					}
				}
			}

			// Associate this tile with the newly created portal
			@portals[tile_key] = portal;
			
			float tile_mid_x = tile_x * 48 + 24;
			float tile_mid_y = tile_y * 48 + 24;
			portal_x += tile_mid_x;
			portal_y += tile_mid_y;
			tile_count++;
			
			if(tile_mid_x < portal_min_x) portal_min_x = tile_mid_x;
			if(tile_mid_y < portal_min_y) portal_min_y = tile_mid_y;
			if(tile_mid_x > portal_max_x) portal_max_x = tile_mid_x;
			if(tile_mid_y > portal_max_y) portal_max_y = tile_mid_y;

			// Check for a tile linking this portal to another
			if (find_link and @portal.linked_portal == null)
			{
				@portal.linked_portal = trace_portal_link(tile_x, tile_y);
				if(@portal.linked_portal != null)
					@portal.linked_portal.linked_portal = @portal;
			}
		}

		tile_queue.reset();

		portal.mid_x = portal_x / tile_count;
		portal.mid_y = portal_y / tile_count;
		portal.init_angle(portal_angle);
		float dx = portal_max_x - portal_min_x;
		float dy = portal_max_y - portal_min_y;
		portal.length = sqrt(dx * dx + dy * dy);

		return portal;
	}

	Portal@ trace_portal_link(int tile_x, int tile_y)
	{
		if (!g.get_tile(tile_x, tile_y, PORTAL_LINK_LAYER).solid())
		{
			return null;
		}

		uint link_length = 0;

		int previous_x = tile_x;
		int previous_y = tile_y;

		// Just follow the link tiles until we find a portal tile
		while (true)
		{
			if (!has_portal(tile_x, tile_y))
			{
				Portal@ portal = trace_portal(secondary_queue, tile_x, tile_y, false);
				if(@portal != null)
				{
					return portal;
				}
			}

			int px = tile_x;
			int py = tile_y;

			if ((tile_x + 1 != previous_x or tile_y != previous_y) and
			g.get_tile(tile_x + 1, tile_y, PORTAL_LINK_LAYER).solid())
				tile_x++;
			else if ((tile_x - 1 != previous_x or tile_y != previous_y) and
			g.get_tile(tile_x - 1, tile_y, PORTAL_LINK_LAYER).solid())
				tile_x--;
			else if ((tile_x != previous_x or tile_y + 1 != previous_y) and
			g.get_tile(tile_x, tile_y + 1, PORTAL_LINK_LAYER).solid())
				tile_y++;
			else if ((tile_x != previous_x or tile_y - 1 != previous_y) and
			g.get_tile(tile_x, tile_y - 1, PORTAL_LINK_LAYER).solid())
				tile_y--;
			else
			{
				puts("!!! END OF LINK [" + tile_x + ", " + tile_y + "]");
				break;
			}
			
			// puts("  tracing [" + tile_x + ", " + tile_y + "]");

			previous_x = px;
			previous_y = py;
			
			if (link_length++ >= MAX_LINK_LENGTH)
			{
				puts("!!! MAX LINK LENGTH EXCEEDED !!!");
				break;
			}
		}
		
		return null;
	}

	bool is_tile_open(int tile_x, int tile_y, int portal_layer)
	{
		return !g.get_tile(tile_x, tile_y, portal_layer).solid() and !g.get_tile(tile_x, tile_y, 19).solid();
	}

}