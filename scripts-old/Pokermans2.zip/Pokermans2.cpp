const float GRAVITY_X = 0;
const float GRAVITY_Y = 30;
const float DRAG = 0.98;
const float FRICTION = 0.9;
const float RESTITUTION = 0.5;

#include "_Fx.cpp"
#include "Pokerball.cpp"

class script
{

	scene@ g;
	controllable@ player;
	dustman@ dm;
	
	FxManager@ fx_manager;
	
	array<Pokerball@> pokerballs = {};
	array<Pokerball@> pokerballs_checkpoint = {};
	uint pokerballs_count = 0;
	uint pokerballs_checkpoint_count = 0;
	
	textfield@ catch_text;
	float catch_text_timer;
	
	textfield@ help_text;
	
	// Game callbacks

	script()
	{
		puts("INIT");
		@g = get_scene();
		
		@fx_manager = FxManager();
		
		@catch_text = create_textfield();
		catch_text.align_horizontal(0);
		catch_text.align_vertical(-1);
		
		@help_text = create_textfield();
		help_text.text(
			"Throw pokerball: Light + Directions\n"
			// + "Inventory: Taunt"
		);
		help_text.align_horizontal(-1);
		help_text.align_vertical(-1);
		help_text.set_font("ProximaNovaReg", 36);
	}
	
	Pokerball@ add_pokerball(Pokerball@ ball)
	{
		if(pokerballs_count >= pokerballs.length())
		{
			pokerballs.resize(pokerballs_count + 10);
		}
		
		@pokerballs[pokerballs_count++] = ball;
		
		return ball;
	}
	
	string get_pokermans_name(string entity_name)
	{
		entity_name = entity_name.substr(6);
		
		if(entity_name == "flag") return "flaggychan";
		
		string result = "";
		
		for(uint i = 0; i < entity_name.length(); i++)
		{
			string ch = entity_name.substr(i, 1);
			result += ch == "_" ? " " : ch;
		}
		
		return result;
	}
	
	void checkpoint_save()
	{
		fx_manager.checkpoint_save();
		
		pokerballs_checkpoint = pokerballs;
		pokerballs_checkpoint_count = pokerballs_count;
	}

	void checkpoint_load()
	{
		@player = null;
		@dm = null;
		
		fx_manager.checkpoint_load();
		
		pokerballs = pokerballs_checkpoint;
		pokerballs_count = pokerballs_checkpoint_count;
	}
	
	void step(int entities)
	{
		if(@player == null)
		{
			entity@e = controller_entity(0);
			if(@e != null)
			{
				@player = e.as_controllable();
				@dm = e.as_dustman();
			}
		}
		else
		{
			if(player.light_intent() == 10)
			{
				float throw_dir = 0;
				
				const int face_y = player.y_intent();
				const int face = player.x_intent() == 0 ? player.face() : player.x_intent();
				const float throw_speed = 1400 + frand() * 700;
				float vel_x;
				float vel_y;
				
				if(face_y == -1)
				{
					throw_dir = 45;
				}
				else if(face_y == 1)
				{
					throw_dir = 135;
				}
				else
				{
					throw_dir = 80;
				}
				
				throw_dir += -5 + frand() * 10;
				throw_dir *= face;
				
				vel_x = sin(throw_dir / 180 * PI) * throw_speed;
				vel_y = -cos(throw_dir / 180 * PI) * throw_speed;
				
				add_pokerball(Pokerball(player.x(), player.y() - 60, vel_x, vel_y));
			}
			
			player.light_intent(0);
			// player.heavy_intent(0);
			
			for(uint i = 0; i < pokerballs_count; i++)
			{
				Pokerball@ ball = pokerballs[i];
				bool alive = pokerballs[i].step(g);
				
				if(alive)
				{
					entity@ e = ball.check_collision(g);
					
					if(@e != null)
					{
						rectangle@ rect = e.as_controllable().collision_rect();
						
						Fx@ fx = Fx(e.x() + rect.left() + rect.get_width() * 0.5, e.y() + rect.top() + rect.get_height() * 0.5, "dustworth", "docleanse");
						fx.start_frame = fx.frame = 7;
						fx_manager.add_fx(fx);
						
						catch_text.text("You caught a " + get_pokermans_name(e.type_name()) + "!");
						catch_text_timer = 60;
						catch_text.colour(0xFFFFFFFF);
						
						const int remove_id = e.id();
						
						g.remove_entity(e);
						alive = false;
						
						for(int a = 0; a < entities; a++)
						{
							entity@ e2 = entity_by_index(a);
							if(e2.type_name() == "AI_controller" and e2.vars().get_var("puppet_id").get_int32() == remove_id)
							{
								g.remove_entity(e2);
								break;
							}
						}
					}
				}
				
				if(!alive)
				{
					@pokerballs[i] = @pokerballs[pokerballs_count - 1];
					@pokerballs[--pokerballs_count] = null;
				}
					
			}
			
			fx_manager.step();
			
			if(catch_text_timer > 1)
			{
				catch_text_timer--;
			}
			else if(catch_text_timer > 0)
			{
				catch_text_timer -= 0.05;
			}
		}
	}
	
	void draw(float sub_frame)
	{
		fx_manager.draw();
		
		for(uint i = 0; i < pokerballs_count; i++)
		{
			pokerballs[i].draw();
		}
		
		if(catch_text_timer > 0)
		{
			if(catch_text_timer < 1)
			{
				catch_text.colour((uint(0xFF * catch_text_timer) << 24) | 0x00FFFFFF);
			}
			catch_text.draw_hud(19, 19, 0, -420, 1, 1, 0);
		}
		
		help_text.draw_hud(19, 19, -800 + 10, -450 + 10, 0.5, 0.5, 0);
	}

}