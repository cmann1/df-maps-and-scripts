const float PI = 3.1415926535897932384626433832795;

float deg2rad(float deg)
{
	return deg / 180 * PI;
}

float rad2deg(float rad)
{
	return rad / PI * 180;
}

float dot(float x1, float y1, float x2, float y2)
{
	return x1 * x2 + y1 * y2;
}

float frand()
{
	return float(rand()) / float(0x3fffffff);
}

float len(float x, float y)
{
	return sqrt(x * x + y * y);
}

float len2(float x, float y)
{
	return x * x + y * y;
}

void normalize(float x, float y, float &out out_x, float &out out_y)
{
	const float len = sqrt(x * x + y * y);
	out_x = x / len;
	out_y = y / len;
}

void project(float ax, float ay, float bx, float by, float &out out_x, float &out out_y)
{
	const float dp = dot(ax, ay, bx, by);
	out_x = ( dp / (bx * bx + by * by) ) * bx;
	out_y = ( dp / (bx * bx + by * by) ) * by;
}

void reflect(float x, float y, float normal_x, float normal_y, float &out out_x, float &out out_y)
{
	float d = dot(x, y, normal_x, normal_y);
	out_x = x - 2 * normal_x * d;
	out_y = y - 2 * normal_y * d;
}

void rotate(float x, float y, float angle, float &out out_x, float &out out_y)
{
	out_x = cos(angle) * x - sin(angle) * y;
	out_y = sin(angle) * x + cos(angle) * y;
}