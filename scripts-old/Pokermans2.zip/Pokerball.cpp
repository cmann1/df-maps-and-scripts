#include "_math.cpp"
#include "_ColType.cpp"
#include "_Sprite.cpp"

class Pokerball
{
	int life = 300;
	float radius = 18;
	
	float x;
	float y;
	float rotation;
	
	float vel_x = 0;
	float vel_y = 0;
	float rotation_vel;
	
	sprites@ sprite;
	float sprite_x;
	float sprite_y;
	
	Sprite@ outer_sprite;
	Sprite@ line_sprite;
	
	Pokerball(float x, float y, float vel_x, float vel_y)
	{
		this.x = x;
		this.y = y;
		this.vel_x = vel_x;
		this.vel_y = vel_y;
		
		@outer_sprite = Sprite("props4", "machinery_18");
		@line_sprite = Sprite("props4", "machinery_6");
		
		rotation_vel = (frand() * 2 - 1) * 15;
		rotation = rand() % 360;
	}
	
	bool step(scene@ g)
	{
		float prev_x = x;
		float prev_y = y;
		
		x += vel_x / 60;
		y += vel_y / 60;
		
		// Cast a ray from the previous position to the new position + radius to finc collisions
		float speed = sqrt(vel_x * vel_x + vel_y * vel_y);
		float dir_x = vel_x / speed;
		float dir_y = vel_y / speed;
		raycast@ ray = g.ray_cast_tiles(prev_x, prev_y, x + dir_x * radius, y + dir_y * radius);
		
		vel_x += GRAVITY_X;
		vel_y += GRAVITY_Y;
		
		vel_x *= DRAG;
		vel_y *= DRAG;
		
		rotation += rotation_vel;
		
		if(ray.hit())
		{
			int angle = ray.angle();
			
			float rad = deg2rad(angle);
			float normal_x = sin(rad);
			float normal_y = -cos(rad);
			
			// Project the ball's position onto the tile surface to "push" the ball out of the collision
			project(prev_x - ray.hit_x(), prev_y - ray.hit_y(), -normal_y, normal_x, dir_x, dir_y);
			x = ray.hit_x() + dir_x + (normal_x * radius);
			y = ray.hit_y() + dir_y + (normal_y * radius);
			
			// Calculate bounce velocity
			const float vn_nn = dot(vel_x, vel_y, normal_x, normal_y) / dot(normal_x, normal_y, normal_x, normal_y);
			const float ux = vn_nn * normal_x;
			const float uy = vn_nn * normal_y;
			const float wx = vel_x - ux;
			const float wy = vel_y - uy;
			
			vel_x = FRICTION * wx - RESTITUTION * ux;
			vel_y = FRICTION * wy - RESTITUTION * uy;
			
			rotation_vel *= FRICTION;
		}
		
		return --life > 0;
	}
	
	entity@ check_collision(scene@ g)
	{
		int collision_count = g.get_entity_collision(y - radius, y + radius, x - radius, x + radius, COL_TYPE_ENEMY);
		
		if(collision_count > 0)
		{
			return g.get_entity_collision_index(0);
		}
		
		return null;
	}
	
	void draw()
	{
		const int layer = 18;
		const int sub_layer = 19;
		
		float scale = 0.8;
		outer_sprite.draw_world(layer, sub_layer,
				0, 0, x, y, rotation,
				scale, scale, 0xFFFF0000);
		
		outer_sprite.draw_world(layer, sub_layer,
				0, 0, x, y, rotation,
				scale * 0.4, scale * 0.4, 0xFF000000);
		
		line_sprite.draw_world(layer, sub_layer,
				0, 0, x, y, rotation,
				scale * 0.32, scale * 0.32, 0xFF000000);
		
		outer_sprite.draw_world(layer, sub_layer,
				0, 0, x, y, rotation,
				scale * 0.33, scale * 0.33, 0xFFFFFFFF);
	}
	
}